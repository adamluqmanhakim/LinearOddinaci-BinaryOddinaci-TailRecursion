package comp352;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class main {

	public static void main(String[] args) {
		double start = System.nanoTime();
		// TODO Auto-generated method stub
		BinaryOdci binary = new BinaryOdci();
		String FN="BinaryOdci.txt";
System.out.println("Its in the file"+FN);

	try {
		PrintWriter outputStream =new PrintWriter(FN);
		
		outputStream.println(binary.BinaryOdci(30));
		
		outputStream.println((System.nanoTime() - start)/1000000000);
		outputStream.close();
		
		
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
	
	}
	}

}
