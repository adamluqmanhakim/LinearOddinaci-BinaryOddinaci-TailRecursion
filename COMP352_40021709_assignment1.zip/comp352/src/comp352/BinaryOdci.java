
package comp352;

public class BinaryOdci {
	public BinaryOdci() {
		//System.out.println("its empty");
	}
	
	public int BinaryOdci(int a) {
		int f0=1;
		int f1=1;
		int f2=1;
		int f;
	
		
		if (a==0)
			f=0;
		else if(a==1||a==2||a==3)
			f=1;
		
		else
			f=BinaryOdci(a-3)+BinaryOdci(a-2)+BinaryOdci(a-1);//not tail recursion
			
		return f;
	}
}

