package comp352;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class mainTailRecursion {
	

	
	public static void main(String[] args) {
		


String FN="TailRecursion.txt";
System.out.println("Its in the file"+FN);

try {
	PrintWriter outputStream =new PrintWriter(FN);
	
	 double start = System.nanoTime();
	
	outputStream.println(TailRecursion(30,1,1,1)+" ");
	outputStream.println((System.nanoTime() - start)/1000000000);
	outputStream.close();
}
catch(FileNotFoundException e) {
	e.printStackTrace();

}

	}
	
	public static int TailRecursion(int n,int a,int b,int c) {
		
		
	if(n<=3)
		return a;
return TailRecursion(n-1,a+b+c,a,b);

	
		
		
			
		
	}
}
