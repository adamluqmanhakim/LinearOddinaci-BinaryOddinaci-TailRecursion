package comp352;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class MainLinear {



		public static void main(String[] args) {
			
		
		
		int []temp;
		
		temp=linearOdci (30);
		
			
			String FN="Linear.txt";
			
			System.out.println("Its in the file "+FN);
			

			 try {
					PrintWriter outputStream =new PrintWriter(FN);
					double start = System.nanoTime();
					outputStream.println(temp[2]);
					outputStream.println((System.nanoTime() - start)/1000000000);
					outputStream.close();
				}
				catch(FileNotFoundException e) {
					e.printStackTrace();

				}

		
		}
		public static int[] linearOdci(int n) {
	      
			int[] A = new int[3]; 
			int a = 0, b = 0, c=0;
			
			if (n== 0)
			{
				a=n;
				b=0;
				c=0;
				
				A[0] = a; A[1] = b; A[2] =c;
				//System.out.print((a+b+c) + " ");
				
				return (A);		// this will return (k, 0)
			}
			else if (n== 1)
			{
				a=n;
				b=1;
				c=1;
				
				A[0] = a; A[1] = b; A[2]=c;
				//System.out.print(a + " " + b + " "+c+" ");
				
				return (A);		// this will return (k, 0)
			}
			else
			{
				
				A = linearOdci(n - 1);
				a = A[0];
				b = A[1];
				c = A[2];
				//System.out.print((a+b+c) + " ");
				A[0] = a+b+c;
				A[1] = a;
				A[2] = b;
				return (A);		// this will return (i+j, j)
			}
	}
}